# Swift Practice Tasks - Solutions

One .swift file per task. Run any file on its own, for example:

    swiftc Unit1_ControlFlow/Task1_1.swift -o task && ./task
    # or: swift Unit1_ControlFlow/Task1_1.swift

Files are self-contained (each declares its own types), so compile them one at a time, not together.
Playground tasks (the "Additional" files) also run in Xcode Playgrounds.
